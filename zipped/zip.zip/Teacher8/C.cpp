#include<bits/stdc++.h>
using namespace std;
 
#define f(i,x,n) for (int i=x;i<n;i++)
#define F first
#define S second
#define pb push_back
#define mp make_pair
#define mt make_tuple
 
typedef long long int ll ;
typedef vector<int> vi ;
typedef priority_queue<int> pqi ;
typedef priority_queue<pair<int,int>> pqp ;
typedef queue<int> qi ;
typedef vector<vector<int>> vvi ;
typedef vector<vector<ll>> vvll ;
typedef vector<vector<pair<int,int>>> vvp ;
typedef vector<bool> vb ;
typedef vector<double> vd ;
typedef vector<vector<char>> vvc ;
typedef vector<char> vc ;
typedef pair<int,int> pii ;
typedef tuple<int,int,int> ti ;
typedef vector<pair<int,int>> vpi ;
typedef vector<tuple<int,int,int>> vti ;
typedef vector<pair<ll,ll>> vpll ;
typedef vector<tuple<ll,ll,ll>> vtll ;
typedef pair<ll,ll> pll ;
typedef tuple<ll,ll,ll> tll ;
typedef vector<ll> vll ;
typedef stack<int> si ;
typedef unordered_map<int,int> uii ;
typedef unordered_map<ll,ll> ull ;
typedef map<int,int> mii ;
typedef set<int> seti ;
typedef double db ;
 
int mod1 = 998244353 ;
int mod2 = 1000000007 ;
int MOD=mod1;
 
ll gcd(ll a, ll b) {
    if(a<b) swap(a,b);
    if(b==0) return a;
    return gcd(b,a%b);
}
 
ll power(ll a, ll n) {
    ll res=1;
    while(n>0) {
        if(n&1) res=(res*a)%MOD;
        a=(a*a)%MOD;
        n/=2;
    }
    return res;
}

bool solve(){
        string s , t ;
        cin >> s >> t;
        char first = t[0] ;
        bool f =false;
        int f_ind ;
        for(int i=0 ; i<s.size() ; i++){
            if(s[i] == first){
                if(!f){
                    f = true;
                    f_ind = i;
                    int cnt = 0;
                    int k = 1;
                    for(int j=i ; j<s.size() ; j++){
                        if(cnt%2==1){
                            if(s[j]==t[k]){
                                k++;
                                cnt = 0;
                            }
                        }
                        if(k==t.size()) return true;
                        cnt ++ ;                        
                    }
                }
                else{
                    if((i-f_ind)%2==1){
                        int cnt = 0;
                        int k = 1;
                        for(int j=i ; j<s.size() ; j++){
                            if(cnt%2==1){
                                if(s[j]==t[k]){
                                    k++;
                                    cnt = 0;
                                }
                            }
                            if(k==t.size()) return true;
                            cnt ++ ;                        
                        }
                        return false;
                    }
                    else{
                        continue;
                    }
                }
            }
        }
    return false;
}
 
int main() {
    ios_base::sync_with_stdio(false) ; cin.tie(NULL) ; cout.tie(NULL) ;
    int q;
    cin>>q;
    while(q--){
        cout << solve() << endl;
    }
    
    return 0;
}